<section class="observation-area">
  <div id="stick">
    <div class="section">
      <h5>I noticed this content contains</h5>
      <a class="option" href="#">CS Issue</a>
      <a class="option" href="#">Safety Issue</a>
      <a class="option" href="#">Profanity</a>
      <a class="option" href="#">Hearsay</a>
      <a class="option" href="#">Wrong Language</a>
      <a class="option" href="#">Pricing</a>
      <a class="option" href="#">Competitors</a>
      <a class="option" href="#">Copyright Issue</a>
      <a class="option" href="#">Contact Info</a>
      <a class="option" href="#">Irrelevant Content</a>
      <a class="option" href="#">Test Content</a>
      <a class="option" href="#">Fraudulent Content</a>
    </div>
    <div class="section">
      <h5>Second opinion on:</h5>
      <a class="option" href="#">Brand</a>
      <a class="option" href="#">Exchange</a>
      <a class="option" href="#">Price</a>
      <a class="option" href="#">Profanity</a>
      <a class="option" href="#">Service</a>
      <a class="option" href="#">Safety Issue</a>
      <a class="option" href="#">Doesn't Match Product</a>
      <a class="option" href="#">Wrong Category</a>
      <a class="option" href="#">Flagged</a>
      <a class="option" href="#">PowerReviews</a>
      <a class="option" href="#">Keyword</a>
    </div>
  </div>
</section>
